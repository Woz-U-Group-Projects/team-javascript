// module.exports = function(models) {
//     models.users.belongsTo(models.posts,{
//         through: models.users,
//         foreignKey: 'UserId'
//     });
//     models.post.belongsTo(models.users,{
//         through: models.posts,
//         foreignKey: 'UserId'
//     });
// }